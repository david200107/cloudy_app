package com.example.cloudy;

import android.app.Activity;
import android.content.Context;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.cloudy.databinding.FragmentHourlyForecastBinding;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class HourlyForecastFragment extends Fragment {

    RecyclerView recyclerView;
    OkHttpClient client;
    String JSONData;
    Button btn;

    ArrayList<Model> list= new ArrayList();
    FragmentHourlyForecastBinding hourlyForecastBinding;
    private GpsTracker GPSLoc;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        hourlyForecastBinding = FragmentHourlyForecastBinding.inflate(getLayoutInflater());
        View view = hourlyForecastBinding.getRoot();

        btn=hourlyForecastBinding.returnButtonHfl;


        GPSLoc = new GpsTracker(getContext());
        GPSLoc.getLocation();
        double[] coordinates=new double[2];
        coordinates[0]=GPSLoc.getLatitude();
        coordinates[1]=GPSLoc.getLongitude();



        Api_requests api_requests=new Api_requests(coordinates[0], coordinates[1]);
        client=new OkHttpClient();
        client.newCall(api_requests.getWeather_request()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
            if(response.isSuccessful()){
                ResponseBody responseBody=response.body();
                JSONData= responseBody.string();
                JSON_Parser json_parser=new JSON_Parser(JSONData);

                ((Activity)getContext()).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        for(int i=0;i<72;i+=2){
                            json_parser.parseJSONData_Hourly(i);

                            try {
                                if(new Datetime().getHour(json_parser.getTime(),"yyyy-MM-dd'T'HH:mm").equals("0")){
                                    list.add(new Model(new Datetime().getDate(json_parser.getTime(),"yyyy-MM-dd'T'HH:mm")));
                                }

                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            try {
                                list.add(new Model(new Datetime().getHour(json_parser.getTime(),"yyyy-MM-dd'T'HH:mm")+":00",json_parser.getWeatherCode_h(),json_parser.getTemperature_h(),
                                        json_parser.getPrecipitation_h(),json_parser.getCloudcover_h(),json_parser.getVisibility_h(),json_parser.getSurface_pressure_h(),
                                        json_parser.getApparent_temperature_h(),json_parser.getRel_humidity_h(),json_parser.getDewpoint_h(),json_parser.getWindspeed_h(),
                                        json_parser.getWindgusts_h()));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }


                        }
                        MultiViewAdapter adapter = new MultiViewAdapter(list,getContext());

                        recyclerView=hourlyForecastBinding.recyclerview;
                        recyclerView.setAdapter(adapter);
                        SimpleItemAnimator itemAnimator= (SimpleItemAnimator) recyclerView.getItemAnimator();
                        itemAnimator.setSupportsChangeAnimations(false);

                    }
                });

            }
            }
        });







        return view;
    }
}