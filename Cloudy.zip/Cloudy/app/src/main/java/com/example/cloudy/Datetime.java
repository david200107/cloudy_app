package com.example.cloudy;

import android.annotation.SuppressLint;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Datetime {
    Datetime(){

    }
    String getDayName(String input) throws ParseException {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat inFormat=new SimpleDateFormat("yyyy-MM-dd");
        Date date=inFormat.parse(input);
        Calendar calendar = Calendar.getInstance();

        assert date != null;
        calendar.setTime(date);

        String[] days = new String[] {  "SUN", "MON", "TUE", "WED", "THU","FRI", "SAT" };

        return days[calendar.get(Calendar.DAY_OF_WEEK)-1];
    }
    String getHour(String input,String pattern) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        SimpleDateFormat output = new SimpleDateFormat("H");
        Date d = null;
        try {
            d = sdf.parse(input);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String formattedTime = output.format(d);


        return formattedTime;

    }
    String getTime(String input,String pattern) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        SimpleDateFormat output = new SimpleDateFormat("HH:mm");
        Date d = null;
        try {
            d = sdf.parse(input);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String formattedTime = output.format(d);


        return formattedTime;

    }

    String getDate(String input,String pattern) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        SimpleDateFormat output = new SimpleDateFormat("MM-dd");
        Date d = null;
        try {
            d = sdf.parse(input);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String formattedDate = output.format(d);


        return formattedDate;

    }
}

