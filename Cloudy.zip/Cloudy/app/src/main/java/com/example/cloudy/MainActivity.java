package com.example.cloudy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.cloudy.databinding.FragmentHomeBinding;
import com.example.cloudy.databinding.NavHeaderLayoutBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.example.cloudy.databinding.FragmentHourlyForecastBinding;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity {



    BottomNavigationView bottomNavigationView;

    NavigationView navigationView;
    DrawerLayout drawerLayout;
    Button button;
    FragmentHourlyForecastBinding fragmentHourlyForecastBinding;
    Button return_button_hff;


    HomeFragment homeFragment;
    HourlyForecastFragment hourlyForecastFragment;
    DailyForecastFragment dailyForecastFragment;
    SettingsFragment settingsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragmentHourlyForecastBinding=FragmentHourlyForecastBinding.inflate(getLayoutInflater());

        setContentView(R.layout.activity_main);
        button=fragmentHourlyForecastBinding.returnButtonHfl;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("BTNC","CLick");
            }
        });

        drawerLayout=findViewById(R.id.drawer);



      homeFragment=new HomeFragment();
      hourlyForecastFragment=new HourlyForecastFragment();
      dailyForecastFragment=new DailyForecastFragment();
      settingsFragment=new SettingsFragment();

        bottomNavigationView=findViewById(R.id.bottom_navigation);

       // getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new HourlyForecastFragment()).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment,homeFragment).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment,hourlyForecastFragment).hide(hourlyForecastFragment).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment,dailyForecastFragment).hide(dailyForecastFragment).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment,settingsFragment).hide(settingsFragment).commit();




        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        //getFragmentManager().popBackStack();
                        getSupportFragmentManager().beginTransaction().hide(hourlyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(dailyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(settingsFragment).commit();
                        getSupportFragmentManager().beginTransaction().show(homeFragment).commit();

                        return true;
                    case R.id.hourly:
                     //   getFragmentManager().popBackStack();

                        getSupportFragmentManager().beginTransaction().hide(homeFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(dailyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(settingsFragment).commit();
                        getSupportFragmentManager().beginTransaction().show(hourlyForecastFragment).commit();

                        return true;
                    case R.id.daily:
                        getSupportFragmentManager().beginTransaction().hide(homeFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(hourlyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(settingsFragment).commit();
                        getSupportFragmentManager().beginTransaction().show(dailyForecastFragment).commit();
                        return true;
                    case R.id.set:
                        getSupportFragmentManager().beginTransaction().hide(hourlyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(dailyForecastFragment).commit();
                        getSupportFragmentManager().beginTransaction().hide(homeFragment).commit();
                        getSupportFragmentManager().beginTransaction().show(settingsFragment).commit();
                        return true;
                }
                return false;
            }
        });

    }
    boolean closeFragment(){

        getSupportFragmentManager().beginTransaction().hide(hourlyForecastFragment).commit();
        getSupportFragmentManager().beginTransaction().hide(dailyForecastFragment).commit();
        getSupportFragmentManager().beginTransaction().hide(settingsFragment).commit();
        getSupportFragmentManager().beginTransaction().show(homeFragment).commit();

        return true;

    }
}