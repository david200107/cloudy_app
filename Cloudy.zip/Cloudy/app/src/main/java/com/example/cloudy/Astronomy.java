package com.example.cloudy;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Astronomy{
Context context;
Activity activity;

TextView sunset,sunrise,dayTime,nightTime,moonrise,moonset;
String jsonSunset,jsonSunrise,jsonDayTime,nightT,jsonMoonrise,jsonMoonset;
private final String API_KEY="043ed98b045a414bb90d51c7404fe804";
double lat,lon;
String url;

    Astronomy(Context context,Activity activity,double lat,double lon){
        this.context=context;
        this.activity=activity;
        this.lat=lat;
        this.lon=lon;
    }

    void initComponets(){
        final LayoutInflater factory = activity.getLayoutInflater();

        final View View = factory.inflate(R.layout.fragment_home, null);
        url="https://api.ipgeolocation.io/astronomy?apiKey="+API_KEY+"&lat="+lat+"&long="+lon;

        sunset=View.findViewById(R.id.sunset);
        sunrise=View.findViewById(R.id.sunrise);
        moonrise=View.findViewById(R.id.moonrise);
        moonset=View.findViewById(R.id.moonset);
       // dayTime=this.activity.findViewById(R.id.day_time);
       // nightTime=this.activity.findViewById(R.id.night_time);
    }
    String getNightLength(String dayLength) throws ParseException {
        String output;
        int total=1440;
        int day,night_min,night_hh=0,night_mm=0;
        SimpleDateFormat inputFormat=new SimpleDateFormat("hh:mm");
        Date date=inputFormat.parse(dayLength);
        SimpleDateFormat hr=new SimpleDateFormat("hh");
        int hour=Integer.parseInt(hr.format(date));
        SimpleDateFormat mn=new SimpleDateFormat("mm");
        int minute=Integer.parseInt(mn.format(date));
        day=hour*60+minute;
        night_min=total-day;
        while(night_min>0){
            if(night_min>60){
                night_hh+=1;
                night_min-=60;
                continue;
            }
            night_mm=night_min;
            break;
        }
         output=String.valueOf(night_hh)+":"+String.valueOf(night_mm);


        return output;
    }





    void getData(){

        initComponets();

        RequestQueue queue = Volley.newRequestQueue(context);


// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JsonParser(response);
                            Log.d("Astronomy",response);


                            ((Activity)context).runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    sunset.setText(jsonSunset);
                                    sunrise.setText(jsonSunrise);
                                    moonrise.setText(jsonMoonrise);
                                    moonset.setText(jsonMoonset);
                                    //dayTime.setText(jsonDayTime);
                                   // nightTime.setText(nightT);

                                }
                            });


                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);

        }

        void JsonParser(String JsonResponse) throws JSONException, ParseException {

        JSONObject jsonObject=new JSONObject(JsonResponse);
        jsonSunrise=jsonObject.getString("sunrise");
        jsonSunset=jsonObject.getString("sunset");
        jsonMoonrise=jsonObject.getString("moonrise");
        jsonMoonset=jsonObject.getString("moonset");
       // jsonDayTime=jsonObject.getString("day_length");
       // nightT=getNightLength(jsonDayTime);

        }





    }

