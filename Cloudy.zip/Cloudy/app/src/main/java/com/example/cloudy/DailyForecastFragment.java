package com.example.cloudy;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.cloudy.databinding.FragmentHourlyForecastBinding;
import com.example.cloudy.databinding.FragmentDailyForecastBinding;


import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class DailyForecastFragment extends Fragment {

    RecyclerView recyclerView;
    OkHttpClient client;
    String JSONData;

    ArrayList<D_Model> list= new ArrayList();
    FragmentHourlyForecastBinding hourlyForecastBinding;
    FragmentDailyForecastBinding dailyForecastBinding;
    private GpsTracker GPSLoc;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);









    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        dailyForecastBinding = FragmentDailyForecastBinding.inflate(getLayoutInflater());
        View view = dailyForecastBinding.getRoot();


        GPSLoc = new GpsTracker(getContext());
        GPSLoc.getLocation();
        double[] coordinates=new double[2];
        coordinates[0]=GPSLoc.getLatitude();
        coordinates[1]=GPSLoc.getLongitude();



        Api_requests api_requests=new Api_requests(coordinates[0], coordinates[1]);
        client=new OkHttpClient();
        client.newCall(api_requests.getWeather_request()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()){
                    ResponseBody responseBody=response.body();
                    JSONData= responseBody.string();
                    JSON_Parser json_parser=new JSON_Parser(JSONData);

                    ((Activity)getContext()).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            for(int i=0;i<7;i++){
                                json_parser.parseJSONData_dailyW(i-1);


                                try {
                                    list.add(new D_Model(json_parser.getDateTime(),json_parser.getWeatherCode_d(),
                                            json_parser.getMaxTemp_d(),json_parser.getMinTemp_d(), json_parser.getPrecipitation_d(), json_parser.getPrecip_hours_d(),
                                            json_parser.getPrecip_probability_d(),json_parser.getMaxWindspeed_d(),json_parser.getMaxWindgusts_d(),json_parser.getWindDirection_d(),json_parser.getUvIndex_d(),
                                            new Datetime().getTime(json_parser.getSunset_d(),"yyyy-MM-dd'T'HH:mm"),new Datetime().getTime(json_parser.getSunrise_d(),"yyyy-MM-dd'T'HH:mm")));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }


                            }
                            D_Adapter adapter = new D_Adapter(list,getContext());

                            recyclerView=dailyForecastBinding.recyclerviewD;
                            recyclerView.setAdapter(adapter);
                            SimpleItemAnimator itemAnimator= (SimpleItemAnimator) recyclerView.getItemAnimator();
                           itemAnimator.setSupportsChangeAnimations(false);

                        }
                    });

                }
            }
        });







        return view;
    }
}